DIRECT_TYPES = ["str", "bool", "code", "int", "float", "Any", "prompt"]
